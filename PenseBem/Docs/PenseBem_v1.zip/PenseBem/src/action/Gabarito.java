package action;

import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.util.LinkedHashMap;
import java.util.ResourceBundle;

import util.RegistraLog;

public class Gabarito {
	private RegistraLog log;
	private String arqRespostas = "";
	private BufferedReader br = null;
	private int quantidadeQuestoes = 10;
	
	public Gabarito (RegistraLog log) {
		this.log = log;	
	}
	
	private void abrirArqRespostas() {
		
		log.debug("Abrindo o arquivo de respostas");
			
		ResourceBundle rd = ResourceBundle.getBundle("resources.config");

		arqRespostas = rd.getString("arquivo_respostas");
		quantidadeQuestoes = Integer.valueOf(rd.getString("quantidade_questoes"));
		
		if (arqRespostas == null) {			
			System.out.println("O nome do arquivo de respostas n�o foi definido.");
		}
		
		log.debug("Abriu o arquivo de respostas");
	
		try {
			br = new BufferedReader(new FileReader(arqRespostas));
		} catch (FileNotFoundException e1) {
			e1.printStackTrace();
			System.exit(0);
		}
	}

	private void fecharArquivosResposta () {
		try {
			br.close();
			log.debug("Fechou o arquivo de respostas");
		} catch (IOException e) {
			e.printStackTrace();
		}
	}

	public LinkedHashMap <Integer, String> pegarRespostas (int inicioResposta) {
		String line = "";
		int gabaritoResposta = 0;
		LinkedHashMap <Integer, String> mapaGabarito = new LinkedHashMap <Integer, String>();
		abrirArqRespostas();
		
		try {
			while ((line = br.readLine()) != null) {
			    String[] row = line.split(";");
			    gabaritoResposta = Integer.valueOf(row[0]);
			    
			    if (gabaritoResposta >= inicioResposta) {   
			    	mapaGabarito.put(gabaritoResposta, row[1]);
			    	log.debug(row[0] + " - " + row[1]);
			    	
			    	if (mapaGabarito.size() == quantidadeQuestoes) {
			    		break;
			    	}
			    }
			}
		} catch (IOException e) {
			e.printStackTrace();
		}
		
		fecharArquivosResposta ();
		
		return mapaGabarito;
	}
}
